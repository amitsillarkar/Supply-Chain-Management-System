const Analytics = () => {
  return <div className="title"> Analytics</div>;
};

export default Analytics;
