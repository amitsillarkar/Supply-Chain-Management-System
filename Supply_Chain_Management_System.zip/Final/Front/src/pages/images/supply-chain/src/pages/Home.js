import React from 'react'

export default function  
Home() {
  return (
    <div className='container'>
        Home
    </div>
  )
}
