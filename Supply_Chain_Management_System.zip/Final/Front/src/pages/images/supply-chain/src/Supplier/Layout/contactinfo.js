import React from 'react'

function Contactinfo() {
  return (
    <div class="d-flex justify-content-center">

        Call on these Number
        <br/>
        8888888888
    </div>
  )
}

export default Contactinfo