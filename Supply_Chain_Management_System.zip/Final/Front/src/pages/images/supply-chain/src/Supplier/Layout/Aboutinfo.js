import React from "react"
import { Card } from "react-bootstrap"
import { CardBody } from "reactstrap"
import CardText from "reactstrap"
import CardTitle from "reactstrap"
import CardSubtitle from "reactstrap"

export default function Aboutinfo () {
  return (
    <div class="p-3 mb-2 bg-secondary text-white" >
<div class="d-flex justify-content-center">
<h1>We produce the Supply Chain Management Solution</h1>
   
   <br/>
   
  
    </div >
    <div class="d-flex justify-content-center">
    <h2>Mobile Phone Business Solutions</h2>
   
   <br/>
   
  
    </div >
    <div class="d-flex justify-content-center">
    <h1>
    <p class="text-primary bg-info">Join Our Team</p></h1>
   
   <br/>
   
  
    </div >
  
    
  </div>

   
      
  )
}
