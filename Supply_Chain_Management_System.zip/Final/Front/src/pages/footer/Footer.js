import React from 'react'
import './Style.css'

export default function Footer() {
  return (
    <div>  <footer id="footerbg" className=' p-4'>
      <div className='uo'>
    <footer className="sticky-footer">
      
      <div className=" p-4 ">
        <div className='row'>
          <div className='col-sm-4'>
            <h5>About Us</h5>
            <p>lorem    </p>

          </div>

          <div className='col-sm-2'>
            <h5>Navigation</h5>
            <p><a href=''>Home</a></p>
            <p><a href=''>About Us</a></p>
            <p><a href=''>Contact Us</a></p>

          </div>
          <div className='col-sm-2'>
            <h5>Services</h5>
            <p><a href=''>Home</a></p>
            <p><a href=''>About Us</a></p>
            <p><a href=''>Contact Us</a></p>

          </div>
          <div className='col-sm-2'>
            <h5>Address</h5>
            <p><a href=''>India</a></p>
            <p><a href=''>po box no-2423</a></p>
            <p><a href=''>+91-9945</a></p>

          </div>
          
        
        <div className="border-top" >
        <section className=' d-flex justify-content-center mt-4'>
        <div className='me-5 d-none d-lg-block'>
          <span> Get Connected With Us On Social Media Network</span>
        </div>
       

      </section>
      </div>
      </div>
      </div >
  </footer>
  </div>
    </footer>
    
    </div>
  )
}
