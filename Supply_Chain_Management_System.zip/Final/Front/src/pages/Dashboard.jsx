const Dashboard = () => {
  return <div className="title"> Dashboard</div>;
};

export default Dashboard;
