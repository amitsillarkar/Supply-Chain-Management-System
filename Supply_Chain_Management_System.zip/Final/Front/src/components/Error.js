import React from 'react'

const Error = () => {
  return (
    <div>Error Page</div>
  )
}

export default Error