import React from 'react'

export default function Backdrop() {
  return (
    <div className='backdrop'>backdrop</div>
  )
}
