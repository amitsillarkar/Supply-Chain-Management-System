package com.scm.service;

public class DistributorServiceImple implements DistributorService{

}
